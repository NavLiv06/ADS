function hide(){
    document.getElementById('obj1').style.display = 'block';
}

const 